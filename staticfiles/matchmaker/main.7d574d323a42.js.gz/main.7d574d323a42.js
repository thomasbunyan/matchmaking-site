//Global Root URL no trailing slash - add slash if using root url
const ROOTURL = window.location.protocol + "//" + window.location.host;

//Make Global for template files to so only compiled once
$(() => {
    window.page = window.location.href.split("/")[3];
    if (window.page === "discover" || window.page === "mymatches") {
        let profiles = document.getElementById("profiles-template").innerHTML;
        window.pstemplate = Handlebars.compile(profiles);
    }
    //Alerts will be on all logged in pages
    if (window.page !== "login" && window.page !== "register" && window.page !== "home") {
        let heatAlert = document.getElementById("alert-heat").innerHTML;
        window.alertHeatTemplate = Handlebars.compile(heatAlert);
        let matchesAlert = document.getElementById("alert-matches").innerHTML;
        window.alertMatchesTemplate = Handlebars.compile(matchesAlert);
    }
});


$(() => {
    if (window.page === "") { initHome(); }
    else if (window.page === "login") { initLogin(); }
    else if (window.page === "register") { initRegister(); }
    else if (window.page === "profile") { initProfile(); getNotifications(); }
    else if (window.page === "discover") { initDiscover(); initSearch(); getNotifications(); }
    else if (window.page === "mymatches") { initMatches(); initSearch(); getNotifications(); }

});

function getNotifications() {
    //Check for new notifications every minute
    $.ajax({
        url: ROOTURL + '/api/notifications/',
        type: "GET",
        data: "json",
        headers: {
            'X-CSRFToken': getCookie("csrftoken"),
        },
        success: (data, status) => {
            if (status) {

                //Set Debug to true to see some examples
                debug = false;

                //If you have new heats generate alert
                if (debug || data.newheats > 0) {
                    $('#allalerts').prepend(window.alertHeatTemplate({ "newmatches": data.newheats }));
                    //console.log("You have new heats!");
                }

                //You have a new match generate alert
                if (debug || data.newmatches > 0) {
                    //console.log("You have new matches!");
                    $('#allalerts').prepend(window.alertMatchesTemplate({ "newmatches": data.newmatches, "nurl": ROOTURL + '/mymatches' }));
                }
                // ? This was annoying me :)
                // console.log(data);
            }
        }
    }).always(function () {
        //Every minute check for new notifications
        setTimeout(getNotifications, 60000);
    });

}

function initHome() {
    // Home js.
    //console.log("Home");
}

function initLogin() {
    // Login js.
    console.log("Login");
    $('#loginButton').click(() => {
        let form = getFormData($("#login"));
        form.csrfmiddlewaretoken = getCookie("csrftoken");

        // Validate frontend here.
        let valid = true;
        if (!valid) {
            console.log("Not valid");
            return;
        }

        const url = ROOTURL + "/api/login/";
        $.ajax({
            url: url,
            type: "POST",
            data: form,
            dataType: "json",
            success: (data, status) => {
                if (status) {
                    if (data.success) {
                        const next = getUrlParameter("next");
                        if (next !== undefined) {
                            window.location.replace(ROOTURL + next);
                        } else {
                            window.location.replace(ROOTURL + "/" + data.redirect);
                        }
                    } else {
                        $('#allalerts').prepend('<div class="alert alert-warning alert-dismissible fade show" role="alert"> The username or password is <strong> incorrect!</strong> Please try again. <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button> </div>');
                    }
                } else {
                    console.log("Unable to POST");
                }
            }
        });

        // console.log(form)
    });
}

function initRegister() {
    // Register js.
    console.log("Register");
    $('#registerButton').click(() => {
        let form = getFormData($("#register"));

        // Validate frontend here.
        let valid = true;
        if (!valid) {
            console.log("Not valid");
            return;
        }

        // Need a username, use the email.
        form.username = form.email;

        const url = ROOTURL + "/api/register/";
        $.ajax({
            url: url,
            type: "POST",
            data: form,
            headers: {
                'X-CSRFToken': getCookie("csrftoken"),
            },
            dataType: "json",
            success: (data, status) => {
                if (status) {
                    if (data.success) {
                        window.location.replace(ROOTURL + "/" + data.redirect);
                    } else {
                        validateForm(data.errors);
                    }
                } else {
                    console.log("Unable to POST");
                }
            }
        });

    });
}

function initProfile() {
    // Profile js.
    //console.log("Profile");
    var hobbies = [];
    var allHobbies = [];
    const url = ROOTURL + '/api/profile/';
    const url2 = ROOTURL + '/api/hobbies/';
    $.ajax({
        url: url,
        type: "GET",
        data: "json",
        success: (data, status) => {
            if (status) {
                console.log(data);
                $('#tFirstName').text(data.firstname);
                $('#tLastName').text(data.lastname);
                $('#first_name')[0].value = data.firstname;
                $('#last_name')[0].value = data.lastname;
                $('#tViews').text(data.views);
                $('#tHeat').text(data.heat);
                $('#email')[0].value = data.email;
                $('#gender')[0].value = data.gender;
                $('#description')[0].value = data.description;
                $('#location')[0].value = data.location;
                $('#dob')[0].value = data.dob;
                $('#adjective1')[0].value = ((data.adjectives.split(",")[0] == undefined || data.adjectives.split(",")[0] == "adjective") ? '' : data.adjectives.split(",")[0]);
                $('#adjective2')[0].value = ((data.adjectives.split(",")[1] == undefined || data.adjectives.split(",")[1] == "adjective") ? '' : data.adjectives.split(",")[1]);
                $('#adjective3')[0].value = ((data.adjectives.split(",")[2] == undefined || data.adjectives.split(",")[2] == "adjective") ? '' : data.adjectives.split(",")[2]);
                $('#profile-picture').attr("src", data.image);
                hobbies = data.hobbies;
                hobbies.forEach(hobby => {
                    $('#picked-hobbies').append("<span class='btn btn-primary mx-1 my-1 selectedHobbies'>" + hobby + "</span>");
                });
                $('#addHobby').click(() => {
                    let option = $('#hobbies').find(":selected").val();
                    if (option != "Choose..." && hobbies.findIndex(e => {
                        return e == option;
                    }) == -1) {
                        hobbies.push(option);
                        $('#picked-hobbies').append("<span class='btn btn-primary mx-1 my-1 selectedHobbies'>" + option + "</span>");
                        addHobbyButtonListeners(hobbies);
                    }
                });
                addHobbyButtonListeners(hobbies);
            }
        }
    });
    $.ajax({
        url: url2,
        type: "GET",
        data: "json",
        success: (data, status) => {
            allHobbies = data;
            if (status) {
                data.forEach(hobby => {
                    $('#hobbies').append("<option>" + hobby.fields.name + "</option>")
                });
            }
        }
    });
    $('#updateButton').click(() => {
        let form = getFormData($("#updateProfile"));
        let updateHobbies = [];
        hobbies.forEach(h => {
            const index = allHobbies.findIndex((aH) => {
                return aH.fields.name == h;
            });
            updateHobbies.push(allHobbies[index].pk);
        });

        const update = {
            first_name: form.first_name,
            last_name: form.last_name,
            username: form.email,
            email: form.email,
            gender: $('#gender').find(":selected").val(),
            description: form.description,
            location: form.location,
            dob: form.dob,
            adjectives: form.adjective1.replace(/ /g, '') + "," + form.adjective2.replace(/ /g, '') + "," + form.adjective3.replace(/ /g, ''),
            hobbies: updateHobbies,
            pw: false
            // image: $('#profile-picture').attr("src")
        }

        if (update.email == undefined || update.email == "") {
            handleUpdateErrors(undefined, { email: ["This field is required."] }, undefined);
            return;
        }
        if (update.first_name == undefined || update.first_name == "") {
            handleUpdateErrors(undefined, { first_name: ["This field is required."] }, undefined);
            return;
        }

        if (form.new_password1 != "" || form.new_password2 != "" || form.old_password != "") {
            update.pw = true;
            update.old_password = form.old_password;
            update.new_password1 = form.new_password1;
            update.new_password2 = form.new_password2;
        }

        $.ajax({
            url: url,
            type: "PUT",
            headers: { "X-CSRFToken": getCookie("csrftoken") },
            data: update,
            dataType: "json",
            success: (data, status) => {
                if (status) {
                    console.log(data)
                    handleUpdateErrors(data.errors_profile, data.errors_user, data.errors_pw);
                    $('#tFirstName').text(form.first_name);
                    $('#tLastName').text(form.last_name);
                }
            }
        });
    });
}

function handleUpdateErrors(profile, user, pw) {
    if (user != undefined && user.first_name) {
        $('#first_name').addClass("is-invalid");
        $('#errorFirstName').text(user.first_name[0]);
    } else {
        $('#first_name').removeClass("is-invalid").addClass("is-valid");
    }
    if (user != undefined && user.last_name) {
        $('#last_name').addClass("is-invalid");
        $('#errorLastName').text(user.last_name[0]);
    } else {
        $('#last_name').removeClass("is-invalid").addClass("is-valid");
    }
    if (user != undefined && user.email) {
        $('#email').addClass("is-invalid");
        $('#errorEmail').text(user.email[0]);
    } else {
        $('#email').removeClass("is-invalid").addClass("is-valid");
    }
    if (profile != undefined && profile.description) {
        $('#description').addClass("is-invalid");
        $('#errorDescription').text(profile.description[0]);
    } else {
        $('#description').removeClass("is-invalid").addClass("is-valid");
    }
    if (profile != undefined && profile.location) {
        $('#location').addClass("is-invalid");
        $('#errorLocation').text(profile.location[0]);
    } else {
        $('#location').removeClass("is-invalid").addClass("is-valid");
    }
    if (profile != undefined && profile.dob) {
        $('#dob').addClass("is-invalid");
        $('#errorDOB').text(profile.dob[0]);
    } else {
        $('#dob').removeClass("is-invalid").addClass("is-valid");
    }
    if (pw) {
        if (pw.old_password != undefined) {
            $('#old_password').addClass("is-invalid");
            $('#errorOldPassword').text(pw.old_password[0]);
        } else {
            $('#old_password').removeClass("is-invalid").addClass("is-valid");
        }
        if (pw.new_password1 != undefined) {
            $('#new_password1').addClass("is-invalid");
            $('#errorPassword1').text(pw.new_password1[0]);
        } else {
            $('#new_password1').removeClass("is-invalid").addClass("is-valid");
        }
        if (pw.new_password2 != undefined) {
            $('#new_password2').addClass("is-invalid");
            $('#errorPassword2').text(pw.new_password2[0]);
        } else {
            $('#new_password2').removeClass("is-invalid").addClass("is-valid");
        }
    } else {
        $('#old_password').removeClass("is-invalid");
        $('#new_password1').removeClass("is-invalid");
        $('#new_password2').removeClass("is-invalid");
    }
}

function uploadProfileImage() {
    var data = new FormData();
    $.each($('#profile-picture-input')[0].files, function (i, file) {
        data.append('file-' + i, file);
    });
    $.ajax({
        url: ROOTURL + '/api/profile/',
        data: data,
        headers: { "X-CSRFToken": getCookie("csrftoken") },
        cache: false,
        contentType: false,
        processData: false,
        method: 'POST',
        type: 'POST',
        success: function (data) {
            if (data.success) {
                var picture = $('#profile-picture')[0];
                var file = $('#profile-picture-input')[0].files[0];
                var fileReader = new FileReader();
                fileReader.onloadend = function () {
                    picture.src = fileReader.result;
                }
                if (file) {
                    fileReader.readAsDataURL(file);
                }
            }
        }
    });
}

function addHobbyButtonListeners(hobbies) {
    $('.selectedHobbies').click((e) => {
        let removeHobby = e.target.innerHTML;
        let index = hobbies.findIndex(e => {
            return e == removeHobby;
        });
        hobbies.splice(index, 1);
        e.target.remove();
    });
}

function initSearch() {
    $('#filterButton').click(() => {
        let form = getFormData($("#search"));

        //console.log(form.minAge, form.maxAge, form.gender)
        const page = window.location.href.split("/")[3];
        if (page === "discover") { initDiscover(form.minAge, form.maxAge, form.gender); }
        else if (page === "mymatches") { initMatches(form.minAge, form.maxAge, form.gender); }

    });
}

function initMatches(minAge, maxAge, gender) {
    getProfiles(minAge, maxAge, gender, true)

}

function initDiscover(minAge, maxAge, gender) {
    getProfiles(minAge, maxAge, gender, null)
}


function getProfiles(minAge, maxAge, gender, matches) {

    //console.log("get Profiles");
    const date = new Date();
    const csrf = getCookie("csrftoken");
    let profiles = [];
    let url = ROOTURL + '/api/profiles/?json';

    // console.log(minAge, maxAge, gender)

    if (minAge) {
        url = url + "&minAge=" + minAge;
    }

    if (maxAge) {
        url = url + "&maxAge=" + maxAge;
    }

    if (gender) {
        url = url + "&gender=" + gender;
    }

    if (matches) {
        url = url + "&matches=true";
    }

    console.log(url)

    // GET data.
    //const url = ROOTURL + "/api/profiles/";
    $.ajax({
        url: url,
        type: "GET",
        data: "json",
        success: (data, status) => {
            if (status) {

                document.getElementById("profile-block").innerHTML = window.pstemplate(data);

                $('.profile-card').click((e) => {
                    const id = e.currentTarget.id + "Modal"
                    profileView(e.currentTarget.id)
                    $('#' + id).modal();
                });

                addAllFuncs();

            }
        }
    });

    // Click on profile to view the modal.
    $('.profile-card').click((e) => {
        const id = e.currentTarget.id + "Modal"
        profileView(e.currentTarget.id)
        $('#' + id).modal();
    });


    function addAllFuncs() {
        $('.heat-icon').click((e) => {
            e.stopImmediatePropagation();
            //window.alert('Hiiii');
            $(e.target).toggleClass('heat-icon-active heat-icon');
            addAllFuncs();
            addHeat(e);
        });

        $('.heat-icon-active').click((e) => {
            e.stopImmediatePropagation();
            $(e.target).toggleClass('heat-icon-active heat-icon');
            addAllFuncs();
            removeHeat(e);
        });
    }

    function profileView(id) {
        //Using head because not all data needs to be returned
        console.log(id);
        $.ajax({
            url: ROOTURL + "/api/profile/" + id + "/",
            type: 'HEAD',
            data: "json"
        });
    }


    function addHeat(e) {
        const id = $(e.currentTarget).closest('.profile-card').attr('id');
        //console.log("Make profile", id, "hot.");
        let form = {};
        form.username = id;
        form.csrfmiddlewaretoken = getCookie("csrftoken");
        //Making hot cal call
        $.ajax({
            url: ROOTURL + "/api/heat/",
            type: "POST",
            data: form,
            dataType: "json",
            success: (data, status) => {
                if (status) {
                    //console.log("made hot")
                }
            }
        });
    }

    function removeHeat(e) {
        const id = $(e.currentTarget).closest('.profile-card').attr('id');
        //console.log("Delete", id, "Heat.");
        let form = {};
        form.username = id;
        form.csrfmiddlewaretoken = getCookie("csrftoken");
        //Making hot cal call
        $.ajax({
            url: ROOTURL + "/api/heat/",
            type: "DELETE",
            headers: {
                'X-CSRFToken': getCookie("csrftoken"),
            },
            data: form,
            dataType: "json",
            success: (data, status) => {
                if (status) {
                    //console.log("Delete heat")
                }
            }
        });
    }


    // On init set the user's age from their DOB.
    $(".age").each(function () {
        let dob = $(this).text();
        try {
            let diff = (date - new Date(dob)) / 1000;
            diff /= (60 * 60 * 24);
            let age = Math.abs(Math.round(diff / 365.25));
            if (isNaN(parseFloat(age))) {
                $(this).text("?");
            } else {
                $(this).text(age);
            }
        } catch (e) {
        }
    });

    // On init set the user's location to '?' if not specified.
    $(".location").each(function () {
        let loc = $(this).text();
        if (loc === "Town/City") {
            $(this).text("?");
        }
    });

    // On init set the user's adjectives and remove if none.
    $(".adjectives").each(function () {
        let adjectives = $(this).text();
        adjectives = adjectives.split(",").map(function (item) {
            return item.trim();
        });
        if (adjectives.length <= 1 && adjectives[0] === "adjective") {
            $(this).text("mysterious");
        } else {
            $(this).text(adjectives[0]);
            for (let i = 1; i < adjectives.length && i < 3; i++) {
                $(this).after("<small class='text-uppercase font-weight-bold text-secondary'>" + adjectives[i] + "</small>")
            }
        }
    });
}


// Find cookie and return its value.
function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(";");
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == " ") {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

// Find param and return its value.
function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
}

// Extract data from form.
function getFormData($form) {
    var unindexed_array = $form.serializeArray();
    var indexed_array = {};

    $.map(unindexed_array, function (n, i) {
        indexed_array[n['name']] = n['value'];
    });

    return indexed_array;
}

// Validate profile.
function validateForm(errors) {
    let errorsClean = errors.split("<ul>");
    errorsClean = errorsClean[0].split("<li>")
    for (let i = 0; i < errorsClean.length; i++) {
        errorsClean[i] = errorsClean[i].replace(/ *\<[^)]*\> */g, "");
    }
    console.log(errors);
    console.log(errorsClean);

    let err = false;
    let indexF = errorsClean.findIndex((e) => { return e == "first_name"; });
    if (indexF != -1) {
        $('#firstname').addClass("is-invalid");
        $('#errorFirstname').text(errorsClean[indexF + 1]);
        err = true;
    } else {
        $('#firstname').removeClass("is-invalid").addClass("is-valid");
    }
    let indexL = errorsClean.findIndex((e) => { return e == "last_name"; });
    if (indexL != -1) {
        $('#lastname').addClass("is-invalid");
        $('#errorLastname').text(errorsClean[indexL + 1]);
        err = true;
    } else {
        $('#lastname').removeClass("is-invalid").addClass("is-valid");
    }
    let indexE = errorsClean.findIndex((e) => { return e == "username"; });
    if (indexE != -1) {
        $('#email').addClass("is-invalid");
        $('#errorEmail').text(errorsClean[indexE + 1]);
        err = true;
    } else {
        $('#email').removeClass("is-invalid").addClass("is-valid");
    }
    let indexD = errorsClean.findIndex((e) => { return e == "dob"; });
    if (indexD != -1) {
        $('#dob').addClass("is-invalid");
        $('#errorDob').text(errorsClean[indexD + 1]);
        err = true;
    } else {
        $('#dob').removeClass("is-invalid").addClass("is-valid");
    }
    let indexU = errorsClean.findIndex((e) => { return e == "email"; });
    if (indexU != -1) {
        $('#email').addClass("is-invalid");
        $('#errorEmail').text("Email address is already registered.");
        err = true;
    } else {
        $('#email').removeClass("is-invalid").addClass("is-valid");
    }
    let indexP1 = errorsClean.findIndex((e) => { return e == "password1"; });
    if (indexP1 != -1) {
        $('#password').addClass("is-invalid");
        $('#errorPassword').text(errorsClean[indexP1 + 1]);
        err = true;
    } else {
        $('#password').removeClass("is-invalid").addClass("is-valid");
    }
    let indexP2 = errorsClean.findIndex((e) => { return e == "password2"; });
    if (indexP2 != -1) {
        $('#password2').addClass("is-invalid");
        $('#errorPassword2').text(errorsClean[indexP2 + 1]);
        err = true;
    } else {
        $('#password2').removeClass("is-invalid").addClass("is-valid");
    }

    return err;
}